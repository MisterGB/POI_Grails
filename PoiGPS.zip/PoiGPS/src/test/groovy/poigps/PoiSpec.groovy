package poigps

import grails.testing.gorm.DomainUnitTest
import spock.lang.Specification

class PoiSpec extends Specification implements DomainUnitTest<Poi> {

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
        expect:"fix me"
            true == false
    }
}
