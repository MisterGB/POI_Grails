package poigps

import grails.testing.gorm.DomainUnitTest
import spock.lang.Specification

class ImageSpec extends Specification implements DomainUnitTest<Image> {

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
        expect:"fix me"
            true == false
    }
}
