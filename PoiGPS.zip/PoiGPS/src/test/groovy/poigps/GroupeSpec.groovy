package poigps

import grails.testing.gorm.DomainUnitTest
import spock.lang.Specification

class GroupeSpec extends Specification implements DomainUnitTest<Groupe> {

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
        expect:"fix me"
            true == false
    }
}
