package poigps

class Image {
    String nom
    Poi poi

    static constraints = {
        nom blank:false;
    }
}
