package poigps

class Poi {
    String nom
    String description
    double latitude
    double longitude
    static hasMany = [images:Image,groupes:Groupe]

    static belongsTo =Groupe;

    static constraints = {
        nom blank:false;
        description blank:false;
        latitude blank:false;
        longitude blank:false;

    }
}
