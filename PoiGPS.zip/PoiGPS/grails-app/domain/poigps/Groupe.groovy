package poigps

class Groupe {
    String nom
    String description

    static hasMany = [pois:Poi]
    Image image
    static constraints = {
        nom blank:false;
        description blank:false;
    }
}
