

// Added by the Spring Security Core plugin:
grails.plugin.springsecurity.logout.afterLoginUrl=true
grails.plugin.springsecurity.userLookup.userDomainClassName = 'poigps.User'
grails.plugin.springsecurity.userLookup.authorityJoinClassName = 'poigps.UserRole'
grails.plugin.springsecurity.authority.className = 'poigps.Role'
grails.plugin.springsecurity.requestMap.className = 'poigps.UserRole'
grails.plugin.springsecurity.securityConfigType = 'Requestmap'
grails.plugin.springsecurity.securityConfigType = 'InterceptUrlMap'
grails.plugin.springsecurity.logout.postOnly=false
grails.plugin.springsecurity.controllerAnnotations.staticRules = [
	[pattern: '/',               access: ['permitAll']],
	[pattern: '/error',          access: ['permitAll']],
	[pattern: '/index',          access: ['permitAll']],
	[pattern: '/index.gsp',      access: ['permitAll']],
	[pattern: '/shutdown',       access: ['permitAll']],
	[pattern: '/assets/**',      access: ['permitAll']],
	[pattern: '/**/js/**',       access: ['permitAll']],
	[pattern: '/**/css/**',      access: ['permitAll']],
	[pattern: '/**/images/**',   access: ['permitAll']],
	[pattern: '/**/favicon.ico', access: ['permitAll']]
]

grails.plugin.springsecurity.filterChain.chainMap = [
	[pattern: '/assets/**',      filters: 'none'],
	[pattern: '/**/js/**',       filters: 'none'],
	[pattern: '/**/css/**',      filters: 'none'],
	[pattern: '/**/images/**',   filters: 'none'],
	[pattern: '/**/favicon.ico', filters: 'none'],
	[pattern: '/**',             filters: 'JOINED_FILTERS']
]

grails.plugin.springsecurity.interceptUrlMap = [
        [pattern: '/',               access: ['permitAll']],
        [pattern: '/error',          access: ['permitAll']],
        [pattern: '/index',          access: ['permitAll']],
        [pattern: '/index.gsp',      access: ['permitAll']],
        [pattern: '/shutdown',       access: ['permitAll']],
        [pattern: '/assets/**',      access: ['permitAll']],
        [pattern: '/**/js/**',       access: ['permitAll']],
        [pattern: '/**/css/**',      access: ['permitAll']],
        [pattern: '/**/images/**',   access: ['permitAll']],
        [pattern: '/**/favicon.ico', access: ['permitAll']],

        [pattern: '/error',                 access: ['permitAll']],
        [pattern: '/index',                 access: ['permitAll']],
        [pattern: '/index.gsp',             access: ['permitAll']],
        [pattern: '/',                      access: ['ROLE_ADMIN','ROLE_MODERATOR']],
        [pattern: '/user/**',               access: ['permitAll']],
        [pattern: '/poi/**',                access: ['permitAll']],
        [pattern: '/image/**',              access: ['permitAll']],
        [pattern: '/groupe/**',             access: ['permitAll']],
        [pattern: '/role/**',               access: ['permitAll']],
        [pattern: '/userrole/**',           access: ['permitAll']],
        [pattern: '/shutdown',              access: ['permitAll']],
        [pattern: '/assets/**',             access: ['permitAll']],
        [pattern: '/**/js/**',              access: ['permitAll']],
        [pattern: '/**/css/**',             access: ['permitAll']],
        [pattern: '/**/images/**',          access: ['permitAll']],
        [pattern: '/**/favicon.ico',        access: ['permitAll']],
        [pattern: '/login/**',              access: ['permitAll']],
        [pattern: '/logout',                access: ['permitAll']],
        [pattern: '/logout/**',             access: ['permitAll']]

]